# fuckstudy

App Android nativa (Kotlin + Jetpack Compose, Android 8.0 o superior) para organizar el curso, preparar exámenes y decidir cómo usar el móvil mientras estudias. Une **MIBUNKER** (agenda, horario, exámenes, planes, Pomodoro y hábitos, con tu cuenta de siempre) y **thinktwice** (pausa consciente, bloqueos, rutinas, retos y estadísticas de uso).

Recorrido principal: abres la tarea de hoy → **Empezar a estudiar** → eliges si proteger esos minutos → **Empezar**.

## Novedades de esta versión (fuckstudy)
- **Marca**: «fuckstudy» en el lanzador, la pantalla de apertura, la cabecera, el perfil y las notificaciones. Logotipo en una línea, «fuck» en Inter Regular y «study» en Inter Bold, −0,09 em, letras blancas de vidrio líquido sobre negro sólido (`res/drawable-nodpi/fs_wordmark.png`, `fs_splash_icon.png`). El identificador (`app.minibunker`), la cuenta y el almacenamiento no cambian: la actualización conserva los datos.
- **Cápsula**: Hoy · Agenda · Estudio · **Hábitos** · thinktwice. La sección Notas, el selector Notas/Hábitos y las acciones «Nota» y «Lista» desaparecen; los apuntes antiguos se conservan en el móvil y en la cuenta (no se borran). Una pestaña «Notas» guardada abre Hábitos.
- **Catálogo único de asignaturas** (`Cal.subjList`): las guardadas por el usuario (con su etiqueta y color) más las que solo aparecían en el horario o en exámenes antiguos, sin duplicados por mayúsculas o espacios. Orden por **minutos de clase semanales** (de mayor a menor; sin horas al final; empates en orden alfabético español). Se usa en «Empezar a estudiar», «Añadir examen», «¿Qué nota necesito?» y la lista de asignaturas.
- **Menú anclado compacto** compartido: lista desplazable de unas cuatro filas y media (la media fila y una flecha indican que hay más), altura según el espacio real (barra de estado, teclado, navegación), la selección actual a la vista al abrir. En «Añadir examen»: tres sugerencias + botón **Todas (N)** + entrada manual.
- **Calendario**: títulos breves de eventos y exámenes dentro de cada día y «+N más»; al tocar un día con contenido se abre su lista completa con horas.
- **¿Qué nota necesito?**: cualquier asignatura; si faltan datos lo dice («Aún no hay exámenes registrados de Inglés»); un examen pendiente nunca cuenta como cero.
- **Generar plan de estudio sin IA** (`academic/PlanGen.kt`): plantillas locales para Lengua y Literatura (obras), Filosofía, Geografía, Matemáticas y una secuencia general para el resto; propuesta editable antes de guardar; conserva lo completado; determinista (mismo plan en modo avión) e idempotente.
- **Esfera del temporizador**: líquido del color de acento que se vacía de arriba abajo, con mm:ss legibles sobre la zona llena y la vacía; nivel y cifras salen del mismo cálculo (`StudyEngine.sphereLevel`).
- **Hojas y desplegables** teñidos con el acento elegido (claro y oscuro), con superficie opaca del mismo tono si el equipo no sostiene el desenfoque.
- Retirada la pantalla «Historial de sesiones de bloqueo» y sus accesos; los datos internos se conservan para reglas, retos y estadísticas. El historial de estudio por asignatura sigue en Estudio.

## Compilar e instalar

**Requisitos:** Android Studio Ladybug (2024.2) o posterior, JDK 17 (el que trae Android Studio), un móvil con Android 8.0 (API 26) o superior y un cable USB.

1. Descomprime el ZIP. En Android Studio: **File › Open** y elige la carpeta `minibunker` (el nombre de la carpeta y del paquete se mantienen para que la actualización conserve los datos).
2. Espera a que termine la sincronización de Gradle. La primera vez descarga Gradle 8.14.3, AGP 8.7.3, Kotlin 2.0.21 y las librerías de Compose, y necesita internet.
3. En el móvil: **Ajustes › Información del teléfono** › pulsa 7 veces *Número de compilación*. Luego, en **Opciones de desarrollador**, activa **Depuración USB**.
4. Conecta el móvil, acepta la huella del ordenador y pulsa **Run ▶** (configuración `app`).

Desde terminal: `./gradlew installDebug` (`gradlew.bat installDebug` en Windows). El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

Pruebas de la lógica (motor de reglas, sincronización, temporizador, copias): `./gradlew testDebugUnitTest`.

> fuckstudy usa el mismo identificador que la versión anterior (`app.minibunker`): si ya la tenías instalada, se actualiza encima y conserva agenda, sesiones, reglas y permisos. Convive con thinktwice y con la web de MIBUNKER. Si tenías thinktwice, desactiva su servicio de accesibilidad para no ver dos pausas, e importa su copia desde **Perfil › Datos › Importar copia**.

## Configuración

### Cuenta (MIBUNKER)
fuckstudy usa **la misma cuenta de Firebase** que la web de MIBUNKER (proyecto `mibunker-8783e`, correo y contraseña). Lee y escribe los mismos documentos (`users/{uid}/data/{events|notes|grades|timetable|sessions|plans|habits|subjects|jornada}`, más `meta` y `prefs`) con el mismo formato, así que una cuenta ya poblada recupera su horario, exámenes, notas, hábitos y sesiones, y la web sigue leyendo lo que escribe el móvil.

- No hay que añadir `google-services.json`: se usa la API REST, como la web.
- Si en Google Cloud la clave de API tiene restricción por *referentes HTTP*, las llamadas desde Android se rechazarán: añade una restricción de app Android (paquete `app.minibunker` y huella SHA-1 de tu firma) o quita esa restricción. En la web abierta como archivo local la clave ya funciona sin referente, así que lo normal es que no haga falta tocar nada.
- Sin conexión puedes seguir usando la agenda. Los cambios se guardan en una cola en el móvil y se envían al volver la red, fusionados por elemento con lo que haya en la cuenta. Más detalles en `docs/DATOS.md`.
- **Usar sin cuenta:** la agenda se queda solo en el móvil. Al iniciar sesión más tarde se añade a la cuenta sin borrar nada.

### Permisos (thinktwice)
Se explican al activar la función que los necesita. Puedes estudiar y usar la agenda sin concederlos.

| Función | Permiso | Dónde se concede |
|---|---|---|
| Pausas, bloqueos y estudio protegido | Servicio de accesibilidad de **fuckstudy** | Ajustes › Accesibilidad › Apps instaladas › fuckstudy |
| Estadísticas y retos de uso | Acceso a datos de uso | Ajustes › Apps › Acceso especial › Acceso a datos de uso |
| Aviso de fin de bloque, sesiones y recordatorios | Notificaciones (Android 13+) | Diálogo del sistema |
| Fin de bloque puntual con la pantalla bloqueada | Alarmas exactas (Android 12+) | Perfil › Permisos › Alarmas exactas |

En Android 13+ las apps instaladas fuera de Google Play tienen **ajustes restringidos**: si el interruptor de accesibilidad aparece gris, ve a **Ajustes › Apps › fuckstudy › ⋮ › Permitir ajustes restringidos**.

Recomendado: excluir fuckstudy de la optimización de batería (**Perfil › Permisos › Diagnóstico completo**), sobre todo en Xiaomi, Huawei, Oppo/Realme, Vivo y Samsung.

## Qué hay dentro

```
app/src/main/java/
├── app/minibunker/
│   ├── academic/   Modelos con el formato de MIBUNKER, cálculos (medias, «¿Qué nota necesito?», planes,
│   │               jornada), cambios puros, cola sin conexión (SyncCore) y repositorio con Firestore
│   ├── cloud/      Firebase Auth y Firestore por REST (mismas llamadas que la web)
│   ├── study/      Temporizador por marcas de tiempo, protección vinculada, alarma y notificación
│   ├── link/       «Vincular protección»: reglas de thinktwice que siguen a clases y eventos
│   ├── json/       JSON propio (sin Android) para poder probar la sincronización en la JVM
│   └── ui/         Tema (oscuro de thinktwice, claro y acento de MIBUNKER), superficie translúcida
│                   compartida (cápsula, hojas, menús), pantallas Hoy, Agenda, Estudio, Hábitos, thinktwice
└── app/thinktwice/ Motor, almacenamiento, servicio de accesibilidad, intervención, uso y notificaciones
                    (reutilizados de thinktwice con las ampliaciones descritas en docs/ANDROID.md)
```

- Icono de la app: el de MIBUNKER. Nombre en el lanzador, la apertura, la cabecera, el perfil y las notificaciones: «fuckstudy». Dentro de su pestaña, thinktwice conserva su nombre y su logotipo.
- Fuente: Inter (OFL, local en `res/font`; licencia en `FONT_LICENSE_Inter.txt`).
- Sin IA: todas las decisiones son reglas explícitas.

## Documentación
- `docs/PRUEBAS.md`: qué se ha verificado, cómo y qué queda pendiente en un móvil real, con los recorridos del encargo.
- `docs/DATOS.md`: compatibilidad con la cuenta de MIBUNKER, cola sin conexión y copias de thinktwice.
- `docs/ANDROID.md`: mecanismo de intervención, estudio protegido, reglas vinculadas y limitaciones.
