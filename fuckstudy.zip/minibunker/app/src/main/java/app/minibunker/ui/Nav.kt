package app.minibunker.ui

import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.focus.FocusRequester
import app.minibunker.study.StudyRequest

/** Los cinco destinos estables de la cápsula, en este orden. */
enum class Tab(val label: String) {
    HOY("Hoy"), AGENDA("Agenda"), ESTUDIO("Estudio"), HABITOS("Hábitos"), TT("thinktwice");
    companion object {
        /** Pestaña guardada por una versión anterior: «NOTAS» ya no existe y abre Hábitos. */
        fun restore(name: String?): Tab = when (name) { null -> HOY; "NOTAS" -> HABITOS; else -> entries.firstOrNull { it.name == name } ?: HOY }
    }
}

/** Pantallas de detalle (navegación interior; la cápsula sigue visible). */
sealed interface Dest {
    // Estudio
    data object StudySession : Dest
    data class SubjectHistory(val subject: String) : Dest
    data class SubjectGrades(val subject: String) : Dest
    // thinktwice
    data object Routines : Dest
    data object Challenges : Dest
    data object Stats : Dest
    data object Diagnostics : Dest
    data object Messages : Dest
    data object Templates : Dest
    data object Classify : Dest
    data object About : Dest
    data class RoutineEdit(val id: String?, val exampleId: String? = null) : Dest
    data class ChallengeDetail(val id: String) : Dest
}

/** Hojas de thinktwice que pueden abrirse desde varias pantallas. */
enum class SheetKind { Block, Pause, NewChallenge }

/** Qué se crea desde la acción rápida «Añadir». */
enum class AddKind { EVENT, EXAM, HABIT }

class Nav {
    var tab by mutableStateOf(Tab.HOY)
    private val stacks: Map<Tab, SnapshotStateList<Dest>> = Tab.entries.associateWith { mutableStateListOf<Dest>() }
    var forward by mutableStateOf(true); private set
    var tabChange by mutableStateOf(false); private set
    var toast by mutableStateOf<String?>(null)

    /** Hojas globales. */
    var sheet by mutableStateOf<SheetKind?>(null)
    var studyRequest by mutableStateOf<StudyRequest?>(null)
    var profileOpen by mutableStateOf(false)
    var add by mutableStateOf<AddKind?>(null)
    /** Fecha propuesta para «Añadir» (el día seleccionado en Agenda, o hoy). */
    var addDate by mutableStateOf<String?>(null)
    /** Abrir un elemento concreto en su hoja de edición desde otra pestaña. */
    var openEvent by mutableStateOf<String?>(null)
    var openExam by mutableStateOf<String?>(null)
    /** Día a mostrar en Agenda al llegar desde Hoy. */
    var agendaDay by mutableStateOf<String?>(null)
    /** Sección de Estudio a mostrar (0 estudiar, 1 planes, 2 exámenes). */
    var studySection by mutableStateOf<Int?>(null)
    /** Sección de Agenda (0 mes, 1 horario). */
    var agendaSection by mutableStateOf<Int?>(null)
    /** Control que abrió la última hoja global: recupera el foco al cerrarla. */
    var lastOpener: FocusRequester? = null

    fun stack(t: Tab = tab): List<Dest> = stacks.getValue(t)
    val top: Dest? get() = stacks.getValue(tab).lastOrNull()
    val depth: Int get() = stacks.getValue(tab).size

    fun select(t: Tab) {
        tabChange = true
        // Tocar la pestaña activa vuelve a su raíz.
        if (t == tab) { forward = false; stacks.getValue(t).clear() } else tab = t
    }
    fun push(d: Dest, inTab: Tab = tab) { tabChange = inTab != tab; forward = true; tab = inTab; stacks.getValue(inTab).add(d) }
    fun pop() { tabChange = false; forward = false; val s = stacks.getValue(tab); if (s.isNotEmpty()) s.removeAt(s.lastIndex) }
    fun popTo(n: Int) { tabChange = false; forward = false; val s = stacks.getValue(tab); while (s.size > n) s.removeAt(s.lastIndex) }
    fun show(msg: String) { toast = msg }

    /** «Empezar a estudiar» desde Hoy, un tema del plan o un evento de estudio: misma hoja. */
    fun startStudy(req: StudyRequest = StudyRequest()) { studyRequest = req }

    /** Atrás del sistema: cierra el detalle; en la raíz de otra pestaña vuelve a Hoy. */
    fun back(): Boolean {
        if (stacks.getValue(tab).isNotEmpty()) { pop(); return true }
        if (tab != Tab.HOY) { tabChange = true; tab = Tab.HOY; return true }
        return false
    }
}

val LocalNav = staticCompositionLocalOf<Nav> { error("Nav no disponible") }
/** Se incrementa cada vez que la app vuelve a primer plano (permisos y datos de uso actualizados). */
val LocalResumeTick = compositionLocalOf { 0 }
