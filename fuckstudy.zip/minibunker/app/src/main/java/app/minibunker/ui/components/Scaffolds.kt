package app.minibunker.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.minibunker.ui.LocalNav
import app.minibunker.ui.frost.fadeTop
import app.minibunker.ui.theme.*

/**
 * Pantalla raíz de una pestaña: cabecera fija (título, acciones y perfil) y lista desplazable.
 * El contenido que sale por arriba se desvanece bajo la cabecera; al final de la lista se reserva
 * espacio para que la cápsula no tape el último elemento.
 */
@Composable
fun TabScaffold(
    title: String,
    state: LazyListState = rememberLazyListState(),
    leading: (@Composable RowScope.() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
    below: (@Composable ColumnScope.() -> Unit)? = null,
    content: LazyListScope.() -> Unit,
) {
    val scrolled by remember { derivedStateOf { state.canScrollBackward } }
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxWidth().statusBarsPadding().padding(start = Dim.screenH, end = 8.dp, top = 8.dp)) {
            Row(Modifier.fillMaxWidth().heightIn(min = 52.dp), verticalAlignment = Alignment.CenterVertically) {
                if (leading != null) Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, content = leading)
                else Text(title, style = Type.screenTitle, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f).semantics { heading() })
                actions()
            }
            if (below != null) Column(Modifier.padding(end = 12.dp, top = 8.dp, bottom = 4.dp), content = below)
        }
        LazyColumn(
            Modifier.fillMaxSize().fadeTop(scrolled), state = state,
            contentPadding = PaddingValues(start = Dim.screenH, end = Dim.screenH, top = 8.dp,
                bottom = Dim.listEnd + WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()),
            content = content,
        )
    }
}

/** Pantalla de detalle: Atrás y acciones fijos; título grande al principio del contenido. */
@Composable
fun DetailScaffold(
    title: String,
    state: LazyListState = rememberLazyListState(),
    actions: @Composable RowScope.() -> Unit = {},
    content: LazyListScope.() -> Unit,
) {
    val nav = LocalNav.current
    val scrolled by remember { derivedStateOf { state.canScrollBackward } }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            CircleIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Volver", { nav.pop() }, bg = TT.Control)
            Spacer(Modifier.width(4.dp))
            // El título compacto aparece al desplazar, cuando el grande ya no se ve.
            Text(if (scrolled) title else "", style = Type.cardTitle, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            actions()
        }
        LazyColumn(
            Modifier.fillMaxSize().fadeTop(scrolled), state = state,
            contentPadding = PaddingValues(start = Dim.screenH, end = Dim.screenH,
                bottom = Dim.listEnd + WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()),
        ) {
            item { Text(title, style = Type.screenTitle, modifier = Modifier.padding(top = 4.dp, bottom = 8.dp).semantics { heading() }) }
            content()
        }
    }
}
