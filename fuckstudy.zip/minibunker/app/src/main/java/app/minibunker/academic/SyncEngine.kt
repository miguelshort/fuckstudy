package app.minibunker.academic

import app.minibunker.cloud.AcademicRemote
import app.minibunker.cloud.RemoteDoc
import app.minibunker.json.*

/**
 * Pasos de sincronización sobre [SyncCore] y un [AcademicRemote] (sin hilos ni Android: se prueba en la JVM).
 * El llamante garantiza que no se ejecutan dos sincronizaciones a la vez sobre el mismo núcleo.
 */
object SyncEngine {
    private const val MAX_ATTEMPTS = 5

    fun itemsOf(doc: RemoteDoc?): List<JObj> = doc?.value?.objs("items").orEmpty()

    /** Descarga todas las partes y las acepta como base (lo pendiente sigue aplicándose encima). */
    fun pull(core: SyncCore, remote: AcademicRemote): Map<String, RemoteDoc?> {
        val docs = remote.getMany(Part.entries.map { it.key } + listOf("meta", "prefs"))
        Part.entries.forEach { p -> core.acceptRemote(p, itemsOf(docs[p.key])) }
        return docs
    }

    /**
     * Envía los cambios pendientes de una parte: lee, fusiona por id y escribe con condición de versión.
     * Si otro dispositivo escribió en medio, vuelve a leer y fusionar. Devuelve false si no lo consigue.
     */
    fun pushPart(core: SyncCore, remote: AcademicRemote, part: Part, now: () -> Long = System::currentTimeMillis): Boolean {
        repeat(MAX_ATTEMPTS) {
            val doc = remote.get(part.key)
            val plan = core.preparePush(part, itemsOf(doc))
            if (remote.put(part.key, linkedMapOf("items" to plan.merged, "updated" to now()), doc?.updateTime)) {
                core.confirmPush(plan)
                return true
            }
        }
        return false
    }

    fun pushAll(core: SyncCore, remote: AcademicRemote): Boolean =
        core.dirtyParts().sortedBy { it.ordinal }.map { pushPart(core, remote, it) }.all { it }

    /** Primera vez con una cuenta: crea el documento meta como la web ({v:1, tt:1, created}). */
    fun ensureMeta(remote: AcademicRemote, docs: Map<String, RemoteDoc?>) {
        if (docs["meta"] == null) runCatching { remote.put("meta", linkedMapOf("v" to 1, "tt" to 1, "created" to System.currentTimeMillis()), null) }
    }
}
