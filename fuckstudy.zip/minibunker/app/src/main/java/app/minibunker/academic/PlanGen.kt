package app.minibunker.academic

import java.text.Normalizer

/**
 * Generador de planes de estudio SIN IA: reglas explícitas y plantillas locales.
 *
 * Usa solo la asignatura, los temas escritos por el usuario y la fecha del examen.
 * No inventa el contenido de un tema: «Tema 5» se conserva tal cual en cada actividad.
 * La misma entrada produce siempre el mismo plan (también los mismos identificadores),
 * así que funciona en modo avión y guardar dos veces deja una sola copia.
 */
object PlanGen {
    enum class Kind { LENGUA_OBRA, FILOSOFIA, GEOGRAFIA, MATEMATICAS, GENERAL }

    /**
     * Plantillas locales: una lista de pasos por tipo, en el orden en que se necesitan.
     * «{t}» se sustituye por el tema exactamente como lo escribió el usuario.
     * Se pueden editar aquí; además, cada propuesta se revisa y edita antes de guardarla.
     */
    val TEMPLATES: Map<Kind, List<String>> = mapOf(
        Kind.LENGUA_OBRA to listOf(
            "Identificar el conflicto principal de «{t}»",
            "Relacionar los personajes de «{t}» con el conflicto",
            "Comentar un fragmento de «{t}»",
            "Ensayar una respuesta de examen sobre «{t}»",
        ),
        Kind.FILOSOFIA to listOf(
            "{t} · Formular la tesis del tema",
            "{t} · Reconstruir un argumento paso a paso",
            "{t} · Plantear una objeción y responderla",
            "{t} · Redactar una respuesta razonada",
        ),
        Kind.GEOGRAFIA to listOf(
            "{t} · Localizar o representar el fenómeno en un mapa",
            "{t} · Explicar sus causas",
            "{t} · Practicar con un mapa, gráfico o ejercicio de los apuntes",
        ),
        Kind.MATEMATICAS to listOf(
            "{t} · Revisar un ejemplo resuelto",
            "{t} · Resolver ejercicios sin mirar la solución",
            "{t} · Corregir los errores y repetir los fallados",
        ),
        Kind.GENERAL to listOf(
            "{t} · Comprender: leer y resumir con tus palabras",
            "{t} · Practicar: preguntas o ejercicios de los apuntes",
            "{t} · Repasar: explicarlo sin mirar",
        ),
    )

    fun norm(s: String): String = Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase().trim()

    /** «Tema 5», «Unidad 3»…: una etiqueta numerada sin nombre. Se puede continuar con ella tal cual. */
    fun isBareLabel(topic: String): Boolean =
        Regex("^(tema|unidad|unit|bloque|capitulo|leccion|parte)\\s*\\d+[a-z]?\\.?$").matches(norm(topic))

    fun kind(subject: String, topic: String): Kind {
        val s = norm(subject)
        return when {
            "lengua" in s || "literatura" in s -> if (isBareLabel(topic)) Kind.GENERAL else Kind.LENGUA_OBRA
            "filosof" in s -> Kind.FILOSOFIA
            "geograf" in s -> Kind.GEOGRAFIA
            "matemat" in s || s == "mates" -> Kind.MATEMATICAS
            else -> Kind.GENERAL
        }
    }

    fun steps(subject: String, topic: String): List<String> = TEMPLATES.getValue(kind(subject, topic)).map { it.replace("{t}", topic.trim()) }

    /** Identificador estable: misma entrada → mismo id. */
    fun stableId(gid: String, title: String, n: Int): String {
        var h = 1125899906842597L
        "$gid|$n|$title".forEach { h = 31 * h + it.code }
        return "p" + java.lang.Long.toString(h and Long.MAX_VALUE, 36).take(11)
    }

    /**
     * Genera el plan del examen [g].
     * - Días disponibles: desde [start] (o hoy, si es posterior) hasta la víspera del examen.
     * - Con dos o más días y [review], el último queda para «Repaso general».
     * - Con un solo día, práctica y repaso se reúnen ese día.
     * - Las actividades ya completadas en [existing] se conservan y no se repiten.
     */
    fun generate(g: Grade, topics: List<String>, start: String, today: String, review: Boolean = true, existing: List<PlanItem> = emptyList()): List<PlanItem> {
        val lines = topics.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        if (lines.isEmpty()) return existing.filter { it.done }
        val done = existing.filter { it.done }
        val doneTitles = done.map { norm(it.title) }.toSet()

        val from = maxOf(start.ifEmpty { today }, today)
        val days = mutableListOf<String>()
        var d = from
        while (g.date.isNotEmpty() && d < g.date && days.size < 366) { days += d; d = Cal.addD(d, 1) }
        if (days.isEmpty()) days += if (g.date.isNotEmpty() && g.date < today) g.date else (if (g.date.isNotEmpty()) minOf(from, g.date) else from)

        val reviewDay: String? = if (review && days.size >= 2) days.removeAt(days.lastIndex) else if (review) days.last() else null

        val acts = lines.flatMap { t -> steps(g.subject, t) }.filter { norm(it) !in doneTitles }
        val out = done.toMutableList()
        acts.forEachIndexed { i, title ->
            val day = days[minOf(days.size - 1, (i.toLong() * days.size / maxOf(1, acts.size)).toInt())]
            out += PlanItem(stableId(g.id, title, i), g.id, g.subject, title, day)
        }
        if (reviewDay != null) {
            val title = if (lines.size == 1) "Repaso general · ${lines[0]}" else "Repaso general · " + lines.joinToString(", ")
            if (norm(title) !in doneTitles) out += PlanItem(stableId(g.id, title, acts.size), g.id, g.subject, title, reviewDay, review = true)
        }
        return out.sortedWith(compareBy<PlanItem> { it.date }.thenBy { if (it.review) 1 else 0 })
    }

    /** Recupera los temas de un plan ya guardado (para precargar «Revisar plan»). */
    fun topicsOf(items: List<PlanItem>): List<String> = items.filter { !it.review }.map { t ->
        val q = Regex("«([^»]+)»").find(t.title)?.groupValues?.get(1)
        q ?: t.title.substringBefore(" · ").trim()
    }.filter { it.isNotBlank() }.distinct()
}
