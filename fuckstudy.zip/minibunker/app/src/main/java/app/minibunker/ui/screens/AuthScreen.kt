package app.minibunker.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.minibunker.R
import app.minibunker.academic.AcadState
import app.minibunker.academic.AcademicRepo
import app.minibunker.cloud.AuthException
import app.minibunker.cloud.NetworkException
import app.minibunker.ui.components.*
import app.minibunker.ui.theme.*
import kotlinx.coroutines.launch

private enum class AuthMode { IN, UP, RESET }

/**
 * Acceso con la cuenta de MIBUNKER (correo y contraseña, recuperación). También se puede seguir sin
 * cuenta: la agenda se guarda solo en este móvil y se puede subir a una cuenta más tarde.
 */
@Composable
fun AuthScreen(ac: AcadState) {
    var mode by rememberSaveable { mutableStateOf(AuthMode.IN) }
    var name by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var pw by rememberSaveable { mutableStateOf("") }
    var pw2 by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<Pair<String, Boolean>?>(null) } // texto, es error
    val scope = rememberCoroutineScope()

    fun go() {
        val em = email.trim().lowercase()
        msg = null
        if (!Regex("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$").matches(em)) { msg = "Escribe un correo electrónico válido." to true; return }
        if (mode == AuthMode.RESET) {
            busy = true
            scope.launch {
                msg = try { AcademicRepo.sendReset(em); "Listo. Revisa tu correo (mira también en spam)." to false }
                catch (e: NetworkException) { "Sin conexión a internet." to true } catch (e: Exception) { (e.message ?: "No se pudo enviar.") to true }
                busy = false
            }
            return
        }
        if (pw.length < 6) { msg = "La contraseña debe tener al menos 6 caracteres." to true; return }
        if (mode == AuthMode.UP && pw != pw2) { msg = "Las contraseñas no coinciden." to true; return }
        busy = true
        scope.launch {
            try { AcademicRepo.signIn(em, pw, mode == AuthMode.UP, name.trim()) }
            catch (e: NetworkException) { msg = "Sin conexión a internet. Conéctate para entrar." to true }
            catch (e: AuthException) { msg = (e.message ?: "No se pudo completar.") to true }
            catch (e: Exception) { msg = "No se pudo completar. Inténtalo de nuevo." to true }
            busy = false
        }
    }

    Column(
        Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.verticalGradient(0f to TT.HeroTop, 0.5f to TT.Bg))
            .systemBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(horizontal = Dim.screenH, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(24.dp))
        app.minibunker.ui.components.MbWordmark(height = 64.dp)
        Spacer(Modifier.height(16.dp))
        Text(
            when (mode) {
                AuthMode.IN -> "Entra con tu cuenta de MIBUNKER para ver tu agenda"
                AuthMode.UP -> "Crea tu cuenta y empieza desde cero"
                AuthMode.RESET -> "Te enviaremos un correo para crear una contraseña nueva"
            }, style = Type.secondary, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(24.dp))
        if (mode != AuthMode.RESET) {
            Segmented(listOf("Iniciar sesión", "Crear cuenta"), if (mode == AuthMode.IN) 0 else 1, { mode = if (it == 0) AuthMode.IN else AuthMode.UP; msg = null }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
        }
        if (mode == AuthMode.UP) { AuthField("Tu nombre", name, { name = it.take(40) }, placeholder = "Cómo quieres que te salude"); Spacer(Modifier.height(12.dp)) }
        AuthField("Correo electrónico", email, { email = it.trim() }, KeyboardType.Email, placeholder = "tucorreo@ejemplo.com")
        if (mode != AuthMode.RESET) {
            Spacer(Modifier.height(12.dp))
            AuthField("Contraseña", pw, { pw = it }, KeyboardType.Password, password = true, placeholder = if (mode == AuthMode.IN) "Tu contraseña" else "Mínimo 6 caracteres",
                done = mode == AuthMode.IN, onDone = ::go)
        }
        if (mode == AuthMode.UP) { Spacer(Modifier.height(12.dp)); AuthField("Repite la contraseña", pw2, { pw2 = it }, KeyboardType.Password, password = true, done = true, onDone = ::go) }
        msg?.let { (t, err) ->
            Spacer(Modifier.height(12.dp))
            Text(t, style = Type.secondary.copy(color = if (err) TT.Danger else TT.Positive), textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().semantics { liveRegion = LiveRegionMode.Assertive })
        }
        Spacer(Modifier.height(20.dp))
        PillButton(
            when { busy && mode == AuthMode.UP -> "Creando cuenta…"; busy && mode == AuthMode.IN -> "Entrando…"; busy -> "Enviando…"
                mode == AuthMode.IN -> "Entrar"; mode == AuthMode.UP -> "Crear cuenta"; else -> "Enviar correo" },
            ::go, Modifier.fillMaxWidth(), enabled = !busy,
        )
        Spacer(Modifier.height(8.dp))
        when (mode) {
            AuthMode.IN -> TextLink("¿Has olvidado tu contraseña?") { mode = AuthMode.RESET; msg = null }
            AuthMode.RESET -> TextLink("Volver a iniciar sesión") { mode = AuthMode.IN; msg = null }
            else -> Unit
        }
        Spacer(Modifier.height(20.dp))
        Text("Tu agenda se guarda en tu cuenta y la verás igual en el móvil y en el ordenador. Si te quedas sin conexión puedes seguir usándola y se sincroniza al volver.",
            style = Type.label, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        PillButton("Usar sin cuenta", { AcademicRepo.continueAsGuest() }, Modifier.fillMaxWidth(), tone = ButtonTone.Secondary, enabled = !busy)
        Text("La agenda quedará solo en este móvil. Podrás iniciar sesión después desde Perfil y se añadirá a tu cuenta sin borrar nada.",
            style = Type.label, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
private fun TextLink(text: String, onClick: () -> Unit) {
    Text(text, style = Type.bodyMedium.copy(color = TT.AccentText), modifier = Modifier.clip(CircleShape).pressable { onClick() }.padding(horizontal = 12.dp, vertical = 14.dp))
}

@Composable
private fun AuthField(label: String, value: String, onChange: (String) -> Unit, type: KeyboardType = KeyboardType.Text, password: Boolean = false,
                      placeholder: String? = null, done: Boolean = false, onDone: () -> Unit = {}) {
    Column(Modifier.fillMaxWidth()) {
        FieldLabel(label)
        OutlinedTextField(
            value = value, onValueChange = onChange, singleLine = true, textStyle = Type.body,
            placeholder = placeholder?.let { { Text(it, style = Type.body.copy(color = TT.TextSecondary)) } },
            visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = type, imeAction = if (done) ImeAction.Done else ImeAction.Next),
            keyboardActions = androidx.compose.foundation.text.KeyboardActions(onDone = { onDone() }),
            shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = TT.Control, unfocusedContainerColor = TT.Control,
                focusedBorderColor = TT.Accent, unfocusedBorderColor = Color.Transparent, cursorColor = TT.Accent,
                focusedTextColor = TT.Text, unfocusedTextColor = TT.Text,
            ),
        )
    }
}
