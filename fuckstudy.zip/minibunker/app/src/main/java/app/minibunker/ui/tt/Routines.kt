package app.minibunker.ui.tt

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import app.thinktwice.core.*
import app.thinktwice.data.Store
import app.minibunker.ui.Dest
import app.minibunker.ui.LocalNav
import app.minibunker.ui.SheetKind
import app.minibunker.ui.components.*
import app.minibunker.ui.frost.*
import app.minibunker.ui.theme.*
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.ZoneId

@Composable
fun RoutinesScreen(state: AppState) {
    val nav = LocalNav.current
    var seg by rememberSaveable { mutableIntStateOf(0) }
    val zone = ZoneId.systemDefault()
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(30_000) } }
    val activeIds = RuleEngine.restrictionsAt(state, now, zone).filter { it.kind == Restriction.Kind.ROUTINE }.map { it.id }.toSet()
    val list = if (seg == 0) state.routines.filter { it.id in activeIds } else state.routines

    DetailScaffold("Rutinas", actions = { SmallPill("Nueva", { nav.push(Dest.RoutineEdit(null)) }, Icons.Rounded.Add, tone = ButtonTone.Light); Spacer(Modifier.width(8.dp)) }) {
        item {
            Text("Franjas por día y hora local en las que un grupo de apps queda en pausa. Las vinculadas a una clase o un evento se mueven con ellos.", style = Type.secondary)
            Spacer(Modifier.height(16.dp))
            // La próxima franja que empezará.
            RuleEngine.nextRoutineStart(state, now, zone)?.let { (r, w) ->
                val start = java.time.Instant.ofEpochMilli(w.first).atZone(zone)
                val today = java.time.LocalDate.now(zone)
                val day = when (start.toLocalDate()) { today -> "Hoy"; today.plusDays(1) -> "Mañana"; else -> start.format(java.time.format.DateTimeFormatter.ofPattern("EEEE d MMM", java.util.Locale("es", "ES"))).replaceFirstChar { it.uppercase() } }
                TTCard(onClick = { nav.push(Dest.RoutineEdit(r.id)) }) {
                    Text("Próxima", style = Type.label)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RowIcon(routineIcon(r.icon)); Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(r.name, style = Type.cardTitle)
                            Text("$day · ${Fmt.clock(r.startMin)} – ${Fmt.clock(r.endMin)}", style = Type.secondary)
                        }
                        AppStack(r.packages, 3)
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
            Segmented(listOf("Activas ahora", "Todas"), seg, { seg = it }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
        }
        if (list.isEmpty()) item {
            if (seg == 0) EmptyState(Icons.Rounded.EventRepeat, "Ninguna rutina activa ahora",
                if (state.routines.isEmpty()) "Crea tu primera rutina o parte de un ejemplo." else "Tus rutinas aparecerán aquí durante su horario.",
                if (state.routines.isEmpty()) "Nueva rutina" else null) { nav.push(Dest.RoutineEdit(null)) }
            else EmptyState(Icons.Rounded.EventRepeat, "Sin rutinas", "Programa franjas en las que tus apps distractoras quedan en pausa.", "Nueva rutina") { nav.push(Dest.RoutineEdit(null)) }
        } else item {
            ListGroup {
                list.forEachIndexed { i, r ->
                    if (i > 0) RowDivider()
                    val active = r.id in activeIds
                    ListRow(
                        title = r.name,
                        subtitle = "${Fmt.clock(r.startMin)} – ${Fmt.clock(r.endMin)} · ${scheduleText(r)}\n" +
                            (if (r.isLinked) "Vinculada · " else "") +
                            when { active -> "Activa ahora · ${appsSummary(r.packages.size)}"; r.enabled -> "Programada · ${appsSummary(r.packages.size)}"; else -> "Desactivada" },
                        leading = { RowIcon(routineIcon(r.icon), tint = if (active) TT.Positive else TT.Text) },
                        trailingSwitch = r.enabled,
                        switchLabel = "Activar ${r.name}",
                        onSwitch = { on -> Store.update { s -> s.copy(routines = s.routines.map { if (it.id == r.id) it.copy(enabled = on) else it }) } },
                        onClick = { nav.push(Dest.RoutineEdit(r.id)) },
                    )
                }
            }
        }
        item {
            SectionHeader("Ejemplos")
            Text("Se copian a tus rutinas desactivados; revisa apps y horario antes de activarlos.", style = Type.secondary)
            Spacer(Modifier.height(12.dp))
            ListGroup {
                Defaults.routineExamples.forEachIndexed { i, r ->
                    if (i > 0) RowDivider()
                    ListRow(r.name, "${Fmt.clock(r.startMin)} – ${Fmt.clock(r.endMin)} · ${Fmt.days(r.days)}",
                        leading = { RowIcon(routineIcon(r.icon)) }, chevron = true,
                        onClick = { nav.push(Dest.RoutineEdit(null, r.id)) })
                }
            }
        }
    }
}

/** Días de una rutina (semanal) o su fecha (rutinas vinculadas a un evento). */
fun scheduleText(r: Routine): String {
    val anchor = r.anchorDay?.let { java.time.LocalDate.ofEpochDay(it) }
    val es = java.util.Locale("es", "ES")
    return when (r.schedule) {
        Schedule.WEEKLY -> Fmt.days(r.days)
        Schedule.ONCE -> anchor?.format(java.time.format.DateTimeFormatter.ofPattern("EEEE d MMM", es)) ?: "Una vez"
        Schedule.MONTHLY -> "Cada mes, día ${anchor?.dayOfMonth ?: "?"}"
        Schedule.YEARLY -> "Cada año, " + (anchor?.format(java.time.format.DateTimeFormatter.ofPattern("d MMM", es)) ?: "?")
    }
}

@Composable
fun ChallengesScreen(state: AppState) {
    val nav = LocalNav.current
    DetailScaffold("Retos", actions = { SmallPill("Nuevo", { nav.sheet = SheetKind.NewChallenge }, Icons.Rounded.Add, tone = ButtonTone.Light); Spacer(Modifier.width(8.dp)) }) {
        item {
            Text("Un reto sigue un compromiso durante 24 h, 48 h, 7, 21 o 30 días: una sesión diaria, respetar una rutina o quedarte por debajo de un límite de uso.", style = Type.secondary)
            Spacer(Modifier.height(16.dp))
        }
        val challenges = state.challenges.filter { !it.archived }
        if (challenges.isEmpty()) item {
            EmptyState(Icons.Rounded.Flag, "Sin retos", "Crea uno para seguir tu compromiso día a día.", "Nuevo reto") { nav.sheet = SheetKind.NewChallenge }
        } else items(challenges, key = { it.id }) { c ->
            ChallengeCard(state, c) { nav.push(Dest.ChallengeDetail(c.id)) }
            Spacer(Modifier.height(Dim.related))
        }
    }
}

@Composable
fun ChallengeCard(state: AppState, c: Challenge, onClick: () -> Unit) {
    val statuses = rememberChallengeStatuses(state, c)
    val met = statuses.count { it == DayStatus.MET_MEASURED || it == DayStatus.MET_MANUAL }
    TTCard(onClick = onClick) {
        CardHeader(challengeTitle(c), Challenges.ruleText(c, state.routines.firstOrNull { it.id == c.routineId }?.name), showChevron = true)
        Spacer(Modifier.height(14.dp))
        LinearProgressIndicator(
            progress = { met / c.durationDays.toFloat() }, modifier = Modifier.fillMaxWidth().height(6.dp),
            color = TT.Positive, trackColor = TT.Control, drawStopIndicator = {},
        )
        Spacer(Modifier.height(8.dp))
        Text("$met de ${c.durationDays} ${if (c.durationDays == 1) "día" else "días"} cumplidos", style = Type.secondary)
    }
}

fun challengeTitle(c: Challenge) = when (c.durationDays) { 1 -> "Reto de 24 h"; 2 -> "Reto de 48 h"; else -> "Reto de ${c.durationDays} días" }

@Composable
fun rememberChallengeStatuses(state: AppState, c: Challenge): List<DayStatus> {
    val from = LocalDate.ofEpochDay(c.startEpochDay)
    val needsUsage = c.kind == ChallengeKind.USAGE_GOAL
    val range by rememberRangeUsage(from, if (needsUsage) c.durationDays else 0)
    val usageMap = (range as? RangeResult.Done)?.days?.toMap().orEmpty()
    val today = LocalDate.now()
    val appState = state
    val inputs = object : ChallengeInputs {
        override fun usage(day: LocalDate) = usageMap[day]
        override val state: AppState = appState
        override val zone: ZoneId = ZoneId.systemDefault()
    }
    return Challenges.days(c).map { Challenges.evaluate(c, it, today, inputs) }
}

@Composable
fun RoutineEditorScreen(state: AppState, ac: app.minibunker.academic.AcadState, dest: Dest.RoutineEdit) {
    val nav = LocalNav.current
    val haptic = rememberHaptic()
    val existing = state.routines.firstOrNull { it.id == dest.id }
    val base = existing ?: Defaults.routineExamples.firstOrNull { it.id == dest.exampleId }
        ?: Routine("", "", emptySet(), 22 * 60, 7 * 60, setOf(1, 2, 3, 4, 5), true)
    var name by rememberSaveable { mutableStateOf(base.name) }
    var apps by rememberSaveable { mutableStateOf(base.packages.toList()) }
    var start by rememberSaveable { mutableIntStateOf(base.startMin) }
    var end by rememberSaveable { mutableIntStateOf(base.endMin) }
    var days by rememberSaveable { mutableStateOf(base.days.toList()) }
    var enabled by rememberSaveable { mutableStateOf(if (existing == null && dest.exampleId != null) false else base.enabled) }
    var icon by rememberSaveable { mutableStateOf(base.icon) }
    var picking by remember { mutableStateOf(false) }
    var timeFor by remember { mutableStateOf<Int?>(null) } // 0 inicio, 1 fin
    var confirmDelete by remember { mutableStateOf(false) }
    var confirmSkip by remember { mutableStateOf(false) }
    var tried by rememberSaveable { mutableStateOf(false) }
    val zone = ZoneId.systemDefault()
    val activeNow = existing != null && RuleEngine.restrictionsAt(state, System.currentTimeMillis(), zone).any { it.id == existing.id }

    val nameErr = if (tried && name.isBlank()) "Escribe un nombre." else null
    val appsErr = if (tried && apps.isEmpty()) "Elige al menos una app." else null
    val weekly = base.schedule == Schedule.WEEKLY
    val daysErr = if (tried && weekly && days.isEmpty()) "Elige al menos un día." else null
    val linked = existing?.link

    fun build(id: String) = base.copy(id = id, name = name.trim(), packages = apps.toSet(), startMin = start, endMin = end, days = days.toSet(), enabled = enabled, icon = icon)

    DetailScaffold(if (existing == null) "Nueva rutina" else "Editar rutina") {
        if (activeNow) item {
            Banner(BannerKind.Info, "Activa ahora", "Los cambios se aplican al momento. Si necesitas usar las apps, usa la salida de emergencia.",
                "Suspender hasta el final de esta franja") { confirmSkip = true }
            Spacer(Modifier.height(16.dp))
        }
        if (linked != null) item {
            Banner(BannerKind.Info, "Vinculada a ${linkLabel(ac.academic, linked)}",
                "Su hora y sus días siguen a ese elemento: al moverlo, editarlo o borrarlo en la Agenda, esta regla se actualiza sola. Aquí eliges las apps y si está activa.")
            Spacer(Modifier.height(16.dp))
        }
        item {
            LabeledField("Nombre", name, { name = it.take(40) }, error = nameErr, placeholder = "Ej.: Noche")
            Spacer(Modifier.height(20.dp))
            ListGroup {
                ListRow("Empieza", null, leading = { RowIcon(Icons.Rounded.PlayArrow) }, value = Fmt.clock(start), chevron = linked == null, onClick = if (linked == null) ({ timeFor = 0 }) else null)
                RowDivider()
                ListRow("Termina", if (end <= start) "Al día siguiente" else null, leading = { RowIcon(Icons.Rounded.Stop) }, value = Fmt.clock(end), chevron = linked == null, onClick = if (linked == null) ({ timeFor = 1 }) else null)
            }
            Spacer(Modifier.height(20.dp))
            if (weekly && linked == null) {
                Text("Días", style = Type.label.copy(color = TT.Text)); Spacer(Modifier.height(8.dp))
                DayChips(days.toSet()) { d -> days = if (d in days) days - d else days + d }
                daysErr?.let { Text(it, style = Type.label.copy(color = TT.Danger), modifier = Modifier.padding(top = 6.dp)) }
                Text("Si cruza la medianoche, cuenta el día en que empieza.", style = Type.label, modifier = Modifier.padding(top = 8.dp))
            } else {
                ListGroup { ListRow("Cuándo", scheduleText(base), leading = { RowIcon(Icons.Rounded.Event) }) }
            }
            Spacer(Modifier.height(20.dp))
            ListGroup {
                ListRow("Aplicaciones", if (apps.isEmpty()) "Ninguna seleccionada" else appsSummary(apps.size),
                    leading = { RowIcon(Icons.Rounded.Apps) }, chevron = true, onClick = { picking = true })
                RowDivider()
                ListRow("Activada", if (enabled) "Se aplicará en su horario" else "No se aplicará", leading = { RowIcon(Icons.Rounded.PowerSettingsNew) },
                    trailingSwitch = enabled, onSwitch = { enabled = it }, switchLabel = "Activada")
            }
            appsErr?.let { Text(it, style = Type.label.copy(color = TT.Danger), modifier = Modifier.padding(top = 6.dp)) }
            Spacer(Modifier.height(20.dp))
            Text("Icono", style = Type.label.copy(color = TT.Text)); Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("morning", "study", "work", "sleep", "focus", "routine").forEach { k ->
                    Box(Modifier.pressable { icon = k }) { RowIcon(routineIcon(k), tint = if (icon == k) TT.Bg else TT.Text, bg = if (icon == k) TT.Text else TT.Control) }
                }
            }
            Spacer(Modifier.height(28.dp))
            PillButton("Guardar", {
                tried = true
                if (name.isBlank() || apps.isEmpty() || (weekly && days.isEmpty())) return@PillButton
                if (existing != null) Store.update { s -> s.copy(routines = s.routines.map { if (it.id == existing.id) build(existing.id) else it }) }
                else Store.update { s -> s.copy(routines = s.routines + build(Store.newId())) }
                haptic(); nav.show("Rutina guardada"); nav.pop()
            }, Modifier.fillMaxWidth())
            if (existing != null) {
                Spacer(Modifier.height(Dim.related))
                PillButton("Duplicar", {
                    // La copia es una rutina normal (sin vínculo), desactivada.
                    Store.update { s -> s.copy(routines = s.routines + existing.copy(id = Store.newId(), name = existing.name + " (copia)", enabled = false, link = null)) }
                    nav.show("Rutina duplicada (desactivada)"); nav.pop()
                }, Modifier.fillMaxWidth(), tone = ButtonTone.Secondary, icon = Icons.Rounded.ContentCopy)
                Spacer(Modifier.height(Dim.section))
                PillButton("Eliminar rutina", { confirmDelete = true }, Modifier.fillMaxWidth(), tone = ButtonTone.Danger, icon = Icons.Rounded.Delete)
            }
            Spacer(Modifier.height(16.dp))
            Text("Android puede retrasar o detener servicios en segundo plano según el fabricante y el ahorro de batería. Comprueba el estado en Diagnóstico.", style = Type.label)
            Spacer(Modifier.height(Dim.listEnd))
        }
    }

    if (picking) AppPickerSheet("Apps de la rutina", apps.toSet(), { picking = false }) { apps = it.toList(); picking = false }
    timeFor?.let { which -> TimeDialog(if (which == 0) start else end, { timeFor = null }, if (which == 0) "Empieza" else "Termina") { v -> if (which == 0) start = v else end = v; timeFor = null } }
    if (confirmDelete && existing != null) ConfirmDialog("¿Eliminar «${existing.name}»?", "Se borrará la rutina. Si está activa, sus apps quedarán libres salvo que otra regla siga vigente.", "Eliminar",
        onConfirm = {
            Store.update { s -> s.copy(routines = s.routines.filter { it.id != existing.id }, routineSkips = s.routineSkips - existing.id) }
            confirmDelete = false; nav.show("Rutina eliminada"); nav.pop()
        }, onDismiss = { confirmDelete = false })
    if (confirmSkip && existing != null) ConfirmDialog("¿Suspender la rutina ahora?", "Es la salida de emergencia: la rutina dejará de aplicarse hasta el final de la franja actual y volverá en la siguiente. Quedará registrada.", "Suspender",
        onConfirm = {
            val endAt = RuleEngine.currentWindowEnd(existing, System.currentTimeMillis(), zone) ?: System.currentTimeMillis()
            Store.update { s -> s.copy(routineSkips = s.routineSkips + (existing.id to endAt)) }
            Store.log(EventType.ROUTINE_SKIPPED, ref = existing.id)
            confirmSkip = false; nav.show("Rutina suspendida hasta el final de la franja")
        }, onDismiss = { confirmSkip = false })
}

/** Selector de hora sobre la superficie translúcida compartida. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimeDialog(initial: Int, onDismiss: () -> Unit, title: String = "Hora", onPick: (Int) -> Unit) {
    val st = rememberTimePickerState(initial / 60, initial % 60, is24Hour = true)
    FrostSheet(onDismiss, title, primary = "Aceptar", onPrimary = { onPick(st.hour * 60 + st.minute) }) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            TimePicker(st, colors = TimePickerDefaults.colors(
                clockDialColor = TT.Control, selectorColor = TT.Accent, containerColor = TT.Card,
                timeSelectorSelectedContainerColor = TT.Accent, timeSelectorUnselectedContainerColor = TT.Control,
                timeSelectorSelectedContentColor = TT.OnAccent, timeSelectorUnselectedContentColor = TT.Text,
                clockDialSelectedContentColor = TT.OnAccent, clockDialUnselectedContentColor = TT.Text,
                periodSelectorBorderColor = TT.Control,
            ))
        }
    }
}

/** Texto del elemento académico al que está vinculada una regla. */
fun linkLabel(a: app.minibunker.academic.Academic, link: String): String {
    val id = link.substringAfter(":")
    return when (link.substringBefore(":")) {
        "class" -> a.timetable.firstOrNull { it.id == id }?.let { "la clase de ${it.subject} (${app.minibunker.academic.Cal.DAYN[it.day].lowercase()} ${it.start})" } ?: "una clase"
        "event" -> a.events.firstOrNull { it.id == id }?.let { "el evento «${it.title}»" } ?: "un evento"
        else -> "un elemento de la agenda"
    }
}
