package app.minibunker.ui.tt

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import app.thinktwice.core.*
import app.thinktwice.data.Codec
import app.thinktwice.data.Store
import app.thinktwice.system.GuardService
import app.thinktwice.system.Perms
import app.minibunker.ui.Dest
import app.minibunker.ui.LocalNav
import app.minibunker.ui.LocalResumeTick
import app.minibunker.ui.SheetKind
import app.minibunker.ui.components.*
import app.minibunker.ui.frost.*
import app.minibunker.ui.theme.*
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@Composable
fun DiagnosticsScreen(state: AppState) {
    val ctx = LocalContext.current
    val tick = LocalResumeTick.current
    val guardEnabled = remember(tick) { Perms.isGuardEnabled(ctx) }
    val guardRunning = remember(tick) { Perms.isGuardRunning() }
    val usage = remember(tick) { Perms.hasUsageAccess(ctx) }
    val notif = remember(tick) { Perms.notificationsEnabled(ctx) }
    val battery = remember(tick) { Perms.ignoringBatteryOptimizations(ctx) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val fmt = DateTimeFormatter.ofPattern("d MMM HH:mm:ss")
    val last = GuardService.lastEventAt

    DetailScaffold("Diagnóstico") {
        item {
            Text("Estado real de cada función en este momento. Puedes revocar cualquier permiso desde los ajustes normales de Android.", style = Type.secondary)
            Spacer(Modifier.height(16.dp))
            PermCard(
                "Pausas, bloqueos y estudio protegido", "Servicio de fuckstudy en Ajustes › Accesibilidad. Solo detecta qué app se abre; no lee contenido.",
                ok = guardEnabled && guardRunning,
                status = when { guardEnabled && guardRunning -> "Activo"; guardEnabled -> "Activado pero detenido por el sistema"; else -> "Desactivado: pausas y bloqueos no operativos" },
                action = "Abrir Accesibilidad",
            ) { Perms.open(ctx, Perms.accessibilityIntent()) }
            PermCard("Estadísticas", "Acceso a datos de uso: tiempo por app y día. No bloquea apps por sí solo.", usage,
                if (usage) "Concedido" else "No concedido: estadísticas y retos de uso sin datos", "Abrir acceso a uso") { Perms.open(ctx, Perms.usageAccessIntent(ctx)) }
            PermCard("Notificaciones", "Estado de sesiones y recordatorios locales.", notif,
                if (notif) "Permitidas" else "Bloqueadas: no verás la cuenta atrás de sesiones", "Permitir") {
                if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else Perms.open(ctx, Perms.notificationSettingsIntent(ctx))
            }
            PermCard("Ejecución en segundo plano", "Algunos fabricantes detienen servicios para ahorrar batería. Excluir fuckstudy mejora la fiabilidad.", if (battery) true else null,
                if (battery) "Sin restricciones de batería" else "Con optimización de batería (puede retrasar o detener la protección)", "Ajustes de batería") { Perms.open(ctx, Perms.batteryIntent()) }
        }
        item {
            SectionHeader("Actividad")
            ListGroup {
                ListRow("Último evento recibido", null, value = if (last == 0L) "Ninguno" else Instant.ofEpochMilli(last).atZone(ZoneId.systemDefault()).format(fmt))
                RowDivider()
                ListRow("Sesiones activas", null, value = "${state.sessions.count { it.isActive(System.currentTimeMillis()) }}")
                RowDivider()
                ListRow("Rutinas activadas", null, value = "${state.routines.count { it.enabled }}")
                RowDivider()
                ListRow("Guardado local", null, value = Store.lastWriteError?.let { "Error: $it" } ?: "Correcto")
            }
        }
    }
}

@Composable
private fun PermCard(title: String, desc: String, ok: Boolean?, status: String, action: String, onAction: () -> Unit) {
    TTCard {
        Text(title, style = Type.cardTitle)
        Text(desc, style = Type.secondary)
        Spacer(Modifier.height(10.dp))
        StatusDot(ok, status)
        if (ok != true) { Spacer(Modifier.height(12.dp)); SmallPill(action, onAction, Icons.Rounded.OpenInNew) }
    }
    Spacer(Modifier.height(Dim.related))
}

@Composable
fun MessagesScreen(state: AppState) {
    var draft by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var deleting by remember { mutableStateOf<PauseMessage?>(null) }
    val nav = LocalNav.current
    DetailScaffold("Mensajes") {
        item {
            Text("Se muestra uno al azar en cada pausa. Evita frases que culpen o insulten: la idea es invitar a decidir.", style = Type.secondary)
            Spacer(Modifier.height(16.dp))
            ListGroup {
                state.messages.forEachIndexed { i, m ->
                    if (i > 0) RowDivider()
                    ListRow(m.text, if (m.builtIn) "Incluido" else "Tuyo", leading = { RowIcon(Icons.Rounded.FormatQuote) },
                        onClick = if (state.messages.size > 1) ({ deleting = m }) else null)
                }
            }
            Spacer(Modifier.height(20.dp))
            LabeledField("Nueva frase", draft, { draft = it.take(120); err = null }, error = err, help = "Máximo 120 caracteres.", singleLine = false)
            Spacer(Modifier.height(12.dp))
            PillButton("Añadir", {
                val t = draft.trim()
                when {
                    t.length < 3 -> err = "Escribe al menos 3 caracteres."
                    state.messages.any { it.text.equals(t, true) } -> err = "Ya existe esa frase."
                    else -> { Store.update { it.copy(messages = it.messages + PauseMessage(Store.newId(), t, false)) }; draft = ""; nav.show("Frase añadida") }
                }
            }, Modifier.fillMaxWidth())
        }
    }
    deleting?.let { m ->
        ConfirmDialog("¿Eliminar la frase?", "«${m.text}»", "Eliminar",
            onConfirm = { Store.update { s -> s.copy(messages = s.messages.filter { it.id != m.id }) }; deleting = null },
            onDismiss = { deleting = null })
    }
}

@Composable
fun TemplatesScreen(state: AppState) {
    val nav = LocalNav.current
    var editing by remember { mutableStateOf<BlockTemplate?>(null) }
    DetailScaffold("Plantillas", actions = { CircleIconButton(Icons.Rounded.Add, "Nueva plantilla", { editing = BlockTemplate("", "", emptySet(), 30) }) }) {
        item {
            Text("Cada plantilla guarda nombre, apps y duración para iniciar un bloqueo rápido.", style = Type.secondary)
            Spacer(Modifier.height(16.dp))
            if (state.templates.isEmpty()) EmptyState(Icons.Rounded.Dashboard, "Sin plantillas", "Crea una para empezar bloqueos con un toque.", "Nueva") { editing = BlockTemplate("", "", emptySet(), 30) }
            else ListGroup {
                state.templates.forEachIndexed { i, t ->
                    if (i > 0) RowDivider()
                    ListRow(t.name, "${Fmt.duration(t.durationMin * 60_000L)} · ${appsSummary(t.packages.size)}", leading = { RowIcon(routineIcon(t.icon)) }, chevron = true, onClick = { editing = t })
                }
            }
        }
    }
    editing?.let { t -> TemplateSheet(t, { editing = null }) { editing = null; nav.show("Plantilla guardada") } }
}

@Composable
private fun TemplateSheet(t: BlockTemplate, onDismiss: () -> Unit, onSaved: () -> Unit) {
    var name by remember { mutableStateOf(t.name) }
    var apps by remember { mutableStateOf(t.packages) }
    var h by remember { mutableStateOf((t.durationMin / 60).toString()) }
    var m by remember { mutableStateOf((t.durationMin % 60).toString()) }
    var picking by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val total = (h.toIntOrNull() ?: 0) * 60 + (m.toIntOrNull() ?: 0)
    val err = if (total !in 1..1440) "Entre 1 minuto y 24 horas." else null
    FrostSheet(onDismiss, if (t.id.isEmpty()) "Nueva plantilla" else "Editar plantilla", primary = "Guardar", primaryEnabled = name.isNotBlank() && err == null, onPrimary = {
        val nt = t.copy(id = t.id.ifEmpty { Store.newId() }, name = name.trim(), packages = apps, durationMin = total)
        Store.update { s -> s.copy(templates = if (t.id.isEmpty()) s.templates + nt else s.templates.map { if (it.id == t.id) nt else it }) }
        onSaved()
    }) {
        LabeledField("Nombre", name, { name = it.take(30) }, error = if (name.isBlank()) "Escribe un nombre." else null)
        Spacer(Modifier.height(16.dp))
        ListGroup { ListRow("Aplicaciones", appsSummary(apps.size), leading = { RowIcon(Icons.Rounded.Apps) }, chevron = true, onClick = { picking = true }) }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            LabeledField("Horas", h, { h = it.filter(Char::isDigit).take(2) }, Modifier.weight(1f), numeric = true)
            LabeledField("Minutos", m, { m = it.filter(Char::isDigit).take(2) }, Modifier.weight(1f), numeric = true)
        }
        err?.let { Text(it, style = Type.label.copy(color = TT.Danger), modifier = Modifier.padding(top = 6.dp)) }
        if (t.id.isNotEmpty()) {
            Spacer(Modifier.height(24.dp))
            PillButton("Eliminar plantilla", { confirmDelete = true }, Modifier.fillMaxWidth(), tone = ButtonTone.Danger)
        }
    }
    if (picking) AppPickerSheet("Apps de la plantilla", apps, { picking = false }) { apps = it; picking = false }
    if (confirmDelete) ConfirmDialog("¿Eliminar «${t.name}»?", "Las sesiones ya iniciadas no se ven afectadas.", "Eliminar",
        onConfirm = { Store.update { s -> s.copy(templates = s.templates.filter { it.id != t.id }) }; confirmDelete = false; onDismiss() },
        onDismiss = { confirmDelete = false })
}

@Composable
fun AboutScreen() {
    DetailScaffold("Cómo funciona") {
        item {
            val blocks = listOf(
                "Pausas" to "Cuando abres una app con pausa, thinktwice muestra una cuenta atrás. Al terminar decides si salir o continuar. Si continúas, la app queda libre durante el intervalo configurado; salir y volver dentro de ese intervalo no repite la pausa. Al terminar, si sigues dentro, la pausa vuelve a aparecer. Si sales sin continuar, la siguiente apertura empieza una pausa nueva.",
                "Bloqueos y rutinas" to "Son restricciones de thinktwice, no del sistema: funcionan mientras el servicio de accesibilidad de thinktwice esté activo y puedes terminarlas con la salida de emergencia. Si varias reglas se solapan, la app no se libera hasta que termine la última. Llamadas, Ajustes, teclado y el lanzador nunca se bloquean.",
                "Detección" to "thinktwice detecta qué app pasa a primer plano. No detecta el gesto de desplazar (scroll), no lee la pantalla, mensajes ni lo que escribes.",
                "Estadísticas" to "Proceden del registro de uso de Android. Android conserva un historial limitado y algunos fabricantes lo reducen; los días sin registro se muestran como «sin datos».",
                "Fiabilidad" to "El ahorro de batería de algunos fabricantes puede detener el servicio. Si ocurre, thinktwice lo indica como «protección no operativa». Las rutinas se evalúan con la hora local vigente: si cambias de zona horaria, se aplican a la hora de pared del nuevo lugar.",
                "Desinstalación" to "thinktwice no impide desinstalarlo ni revocar sus permisos: siempre tienes el control.",
                "Privacidad" to "Las funciones de thinktwice no necesitan cuenta: permisos, apps elegidas, decisiones e historial de uso se quedan en este móvil y no se envían a ningún sitio. Solo tus datos académicos (horario, exámenes, notas, hábitos y sesiones) se sincronizan con tu cuenta de MIBUNKER si inicias sesión. Sin publicidad ni seguimiento.",
                "Estudio protegido" to "Al activar «Proteger este bloque», fuckstudy crea una sesión de bloqueo de thinktwice que dura lo que queda del bloque. Al pausar o empezar un descanso se suspende solo esa protección; al reanudar se aplica por el tiempo restante. Si también hay una rutina vigente, sigue hasta su propio fin. Una hora planificada o un bloqueo nunca se suman por sí solos al tiempo estudiado.",
            )
            blocks.forEach { (t, d) ->
                Text(t, style = Type.cardTitle, modifier = Modifier.padding(top = 20.dp, bottom = 6.dp))
                Text(d, style = Type.body.copy(color = TT.TextSecondary))
            }
            Spacer(Modifier.height(24.dp))
            Text("thinktwice no promete curar una adicción ni garantiza resultados.", style = Type.label)
            Spacer(Modifier.height(Dim.listEnd))
        }
    }
}
