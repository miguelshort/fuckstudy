package app.minibunker

import app.minibunker.academic.*
import app.minibunker.link.Links
import app.thinktwice.core.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDateTime
import java.time.ZoneId

class AcademicTest {
    private fun ac(vararg parts: Pair<Part, List<Any>>) = Academic(parts.associate { (p, l) ->
        p to l.map { x -> when (x) {
            is Grade -> x.toJson(); is Event -> x.toJson(); is ClassEntry -> x.toJson(); is PlanItem -> x.toJson()
            is Subject -> x.toJson(); is JornadaItem -> x.toJson(); is StudySession -> x.toJson(); else -> error("tipo") } }
    })

    @Test fun weightedAveragesAndNeeded() {
        val a = ac(Part.GRADES to listOf(
            Grade("1", "Geo", score = 6.0, weight = 30.0), Grade("2", "Geo", score = 8.0, max = 10.0, weight = 30.0),
            Grade("3", "Geo", date = "2026-12-10", weight = 40.0), Grade("4", "Mates", score = 15.0, max = 20.0),
        ))
        val geo = Cal.subjects(a).first { it.name == "Geo" }
        assertEquals(7.0, geo.avg!!, 1e-9)
        assertEquals((7.0 + 7.5) / 2, Cal.overall(a)!!, 1e-9)
        val n = Cal.needed(a, "Geo", 7.0) as Cal.Needed.Result
        assertEquals(7.0, n.need, 1e-9)
        assertEquals((6 * 30 + 8 * 30 + 10 * 40) / 100.0, n.max, 1e-9)
        assertTrue(Cal.needed(a, "Mates", 5.0) is Cal.Needed.NoPending)
        assertTrue(Cal.needed(a, "Inglés", 5.0) is Cal.Needed.NoExams)
    }

    @Test fun planSpreadsTopicsAndReservesReview() {
        val g = Grade("g", "Geografía", date = "2026-11-25")
        var k = 0
        val p = Cal.makePlan(g, listOf("Relieve", "Clima", "Ríos", "Población"), "2026-11-20", true, "2026-11-20") { "id${k++}" }
        // Días 20..24 (5), el 24 se reserva para repaso → 4 días para 4 temas.
        assertEquals(listOf("2026-11-20", "2026-11-21", "2026-11-22", "2026-11-23", "2026-11-24"), p.map { it.date })
        assertTrue(p.last().review)
        assertEquals("Repaso general", p.last().title)
    }

    @Test fun repeatsAndExamsInCalendar() {
        val e = Event("e", "2026-11-02", "10:00", "11:00", "Clase de piano", repeat = "weekly")
        assertTrue(Cal.occurs(e, "2026-11-16")); assertFalse(Cal.occurs(e, "2026-11-17")); assertFalse(Cal.occurs(e, "2026-10-26"))
        assertTrue(Cal.occurs(e.copy(repeat = "monthly"), "2026-12-02"))
        assertTrue(Cal.occurs(e.copy(repeat = "yearly"), "2027-11-02"))
        val a = ac(Part.EVENTS to listOf(e), Part.GRADES to listOf(Grade("g", "Geo", date = "2026-11-16", time = "09:00")))
        val items = Cal.dayItems(a, "2026-11-16")
        assertEquals(2, items.size)
        assertTrue(items[0] is Cal.DayItem.Exam) // 09:00 antes que 10:00: el mismo examen, editable
    }

    @Test fun jornadaGenerationAndLosses() {
        val gen = JornadaGen("08:00", 55, 6, 3, 30, 0, 0)
        val s = Cal.genSlots(gen)
        assertEquals(7, s.size)
        assertEquals("10:45" to "11:15", s[3].start to s[3].end) // recreo de 30 min tras la 3.ª (3 × 55 min)
        assertTrue(s[3].isBreak)
        val a = ac(Part.TIMETABLE to listOf(ClassEntry("c1", 1, "08:00", "08:55", "s1", "Mates"), ClassEntry("c2", 6, "08:00", "08:55", "s1", "Lengua")))
        assertEquals(listOf("c2"), Edits.jornadaLosses(a, gen, listOf(1, 2, 3, 4, 5)).map { it.id })
        val ch = Edits.applyJornada(a, gen.copy(start = "08:30"), listOf(1, 2, 3, 4, 5))
        val tt = ch[Part.TIMETABLE]!!.mapNotNull(ClassEntry::from)
        assertEquals(listOf("08:30"), tt.map { it.start })
    }

    @Test fun setCellsAndSubjectRenameCascade() {
        val slot = JornadaItem.Slot("s1", false, "08:00", "09:00")
        var a = ac(Part.JORNADA to listOf(slot, JornadaItem.Cfg()), Part.SUBJECTS to listOf(Subject("x", "Geo", color = "#6f9de0")),
            Part.GRADES to listOf(Grade("g", "Geo")))
        a = Academic(a.raw + Edits.setCells(a, listOf(1, 3), slot, "Geo"))
        assertEquals(2, a.timetable.size)
        val idBefore = a.timetable.first { it.day == 1 }.id
        a = Academic(a.raw + Edits.setCells(a, listOf(1), slot, "Geo"))
        assertEquals(idBefore, a.timetable.first { it.day == 1 }.id) // reasignar conserva el id
        a = Academic(a.raw + Edits.saveSubject(a, "Geo", "Geografía", "Ana", "B2", "#7fbf8e"))
        assertTrue(a.timetable.all { it.subject == "Geografía" && it.room == "B2" })
        assertEquals("Geografía", a.grades.single().subject)
    }

    @Test fun deletingExamDeletesItsPlan() {
        val a = ac(Part.GRADES to listOf(Grade("g", "Geo")), Part.PLANS to listOf(PlanItem("p", "g", "Geo", "T", "2026-11-20"), PlanItem("q", "h", "Mat", "T", "2026-11-20")))
        val ch = Edits.deleteGrade(a, "g")
        assertEquals(listOf("q"), ch[Part.PLANS]!!.map { it["id"] })
    }

    // ───── Protección vinculada ─────

    private val madrid = ZoneId.of("Europe/Madrid")
    private fun at(s: String) = LocalDateTime.parse(s).atZone(madrid).toInstant().toEpochMilli()
    private val ig = "com.instagram.android"

    @Test fun classLinkFollowsTheClass() {
        // Lunes (día 1 en JS) de 10:00 a 11:00.
        var a = ac(Part.TIMETABLE to listOf(ClassEntry("c1", 1, "10:00", "11:00", "s2", "Geo")))
        var rs = Links.upsert(a, emptyList(), Links.classKey("c1"), setOf(ig)) { "r1" }
        rs = Links.upsert(a, rs, Links.classKey("c1"), setOf(ig)) { "r2" }
        assertEquals(1, rs.size) // nunca se duplica
        val st = AppState(routines = rs)
        assertTrue(RuleEngine.decide(st, ig, at("2026-11-16T10:30"), madrid) is Decision.Block)
        assertEquals(Decision.Allow, RuleEngine.decide(st, ig, at("2026-11-17T10:30"), madrid))
        // Se mueve la clase al martes 12:00–13:00.
        a = ac(Part.TIMETABLE to listOf(ClassEntry("c1", 2, "12:00", "13:00", "s4", "Geo")))
        rs = Links.reconcile(a, rs)
        val st2 = AppState(routines = rs)
        assertEquals(Decision.Allow, RuleEngine.decide(st2, ig, at("2026-11-16T10:30"), madrid))
        assertTrue(RuleEngine.decide(st2, ig, at("2026-11-17T12:30"), madrid) is Decision.Block)
        // Se borra la clase (con otro dato aún presente): la regla desaparece.
        a = ac(Part.SUBJECTS to listOf(Subject("x", "Geo")))
        assertTrue(Links.reconcile(a, rs).isEmpty())
    }

    @Test fun oneOffEventProtectsOnlyThatDate() {
        val a = ac(Part.EVENTS to listOf(Event("e1", "2026-11-18", "17:00", "19:00", "Estudiar en biblioteca")))
        val rs = Links.upsert(a, emptyList(), Links.eventKey("e1"), setOf(ig)) { "r" }
        val st = AppState(routines = rs)
        assertTrue(RuleEngine.decide(st, ig, at("2026-11-18T18:00"), madrid) is Decision.Block)
        assertEquals(Decision.Allow, RuleEngine.decide(st, ig, at("2026-11-25T18:00"), madrid))
        assertEquals(Decision.Allow, RuleEngine.decide(st, ig, at("2026-11-11T18:00"), madrid))
        // Sin horas: se conserva desactivada (no se pierden las apps).
        val noTime = ac(Part.EVENTS to listOf(Event("e1", "2026-11-18", title = "Biblioteca")))
        val r2 = Links.reconcile(noTime, rs).single()
        assertFalse(r2.enabled); assertEquals(setOf(ig), r2.packages)
    }

    @Test fun emptyAcademicDoesNotWipeLinkedRules() {
        val rs = listOf(Routine("r", "Clase", setOf(ig), 600, 660, setOf(1), true, link = "class:c1"))
        assertEquals(rs, Links.reconcile(Academic.EMPTY, rs))
    }

    // ───── fuckstudy: catálogo, orden por carga lectiva y planes sin IA ─────

    @Test fun catalogIncludesEverySubjectOnceOrderedByWeeklyMinutes() {
        val subs = (1..10).map { Subject("s$it", "Asig %02d".format(it), color = PALETTE[it % PALETTE.size]) } + Subject("h", "Historia", color = "#e07a6a")
        val a = ac(
            Part.SUBJECTS to subs,
            Part.TIMETABLE to listOf(
                ClassEntry("c1", 1, "08:00", "08:45", subject = "Asig 03"), ClassEntry("c2", 3, "08:00", "08:45", subject = "Asig 03"),
                ClassEntry("c3", 2, "09:00", "10:40", subject = "Asig 07"),
                ClassEntry("c4", 2, "11:00", "11:30", subject = "  historia "), // misma asignatura, otra mayúscula
                ClassEntry("c5", 4, "12:00", "13:00", subject = "Música"),      // solo en el horario antiguo
            ),
            Part.GRADES to listOf(Grade("g1", "Latín", date = "2026-12-01"), Grade("g2", "Historia", score = 7.0)),
        )
        val names = Cal.allSubjects(a)
        assertEquals("Asig 07", names[0])            // 100 min
        assertEquals("Asig 03", names[1])            // 2 × 45 = 90 min
        assertEquals("Música", names[2])             // 60 min
        assertEquals("Historia", names[3])           // 30 min, etiqueta y color del usuario
        assertEquals(1, names.count { Cal.subjKey(it) == "historia" })
        assertEquals("#e07a6a", Cal.subjList(a).first { it.name == "Historia" }.color)
        assertTrue("Latín" in names && "Asig 10" in names)       // sin horas ni exámenes también aparecen
        assertEquals(listOf("Asig 01", "Asig 02"), names.drop(4).take(2)) // sin horas: alfabético al final
        // Cambiar el horario recalcula el orden.
        val b = ac(Part.SUBJECTS to subs, Part.TIMETABLE to listOf(ClassEntry("c1", 1, "08:00", "08:45", subject = "Asig 03")))
        assertEquals("Asig 03", Cal.allSubjects(b)[0])
        assertEquals("Asig 01", Cal.allSubjects(b)[1])
    }

    @Test fun calendarCellsShowTitlesAndMore() {
        val a = ac(
            Part.EVENTS to listOf(Event("e1", "2026-11-20", "09:00", title = "Dentista"), Event("e2", "2026-11-20", "17:00", title = "Fútbol"), Event("e3", "2026-11-13", "18:00", title = "Inglés", repeat = "weekly")),
            Part.GRADES to listOf(Grade("x", "Geografía", date = "2026-11-21")),
        )
        val (t, more) = Cal.cellTitles(a, "2026-11-20", 2)
        assertEquals(listOf("Dentista"), t.map { it.first }); assertEquals(2, more)
        assertEquals(3, Cal.cellTitles(a, "2026-11-20", 3).first.size)
        assertEquals(listOf("Examen Geografía"), Cal.cellTitles(a, "2026-11-21", 3).first.map { it.first })
    }

    @Test fun planGeneratorUsesSubjectSpecificPracticeWithoutAi() {
        val today = "2026-11-20"
        val lengua = PlanGen.generate(Grade("l", "Lengua y Literatura", date = "2026-11-27"), listOf("La casa de Bernarda Alba"), today, today)
        val filo = PlanGen.generate(Grade("f", "Filosofía", date = "2026-11-27"), listOf("Justicia"), today, today)
        val geo = PlanGen.generate(Grade("g", "Geografía", date = "2026-11-27"), listOf("Tema 5"), today, today)
        assertTrue(lengua.any { "conflicto" in it.title && "La casa de Bernarda Alba" in it.title })
        assertTrue(lengua.any { "fragmento" in it.title })
        assertTrue(filo.any { "tesis" in it.title } && filo.any { "objeción" in it.title })
        assertTrue(geo.any { "mapa" in it.title })
        assertTrue(geo.filter { !it.review }.all { it.title.startsWith("Tema 5 · ") })   // conserva el nombre, no inventa contenido
        assertTrue(PlanGen.isBareLabel("Tema 5"))
        listOf(lengua, filo, geo).forEach { p ->
            assertTrue(p.all { it.date < "2026-11-27" && it.date >= today })   // termina a tiempo
            assertTrue(p.last().review && p.last().date == "2026-11-26")     // último día, repaso
            assertTrue(p.dropLast(1).all { it.date < "2026-11-26" })
            assertEquals(p.sortedBy { it.date }.map { it.title }, p.map { it.title }) // en orden
        }
        // Determinista: la misma entrada da el mismo plan (ids incluidos).
        assertEquals(geo, PlanGen.generate(Grade("g", "Geografía", date = "2026-11-27"), listOf("Tema 5"), today, today))
        // Matemáticas y genérico distintos de Geografía.
        val mates = PlanGen.generate(Grade("m", "Matemáticas", date = "2026-11-27"), listOf("Derivadas"), today, today)
        assertTrue(mates.any { "sin mirar la solución" in it.title })
    }

    @Test fun planGeneratorKeepsDoneItemsAndHandlesOneDay() {
        val today = "2026-11-20"; val g = Grade("g", "Geografía", date = "2026-11-25")
        val first = PlanGen.generate(g, listOf("Relieve", "Clima"), today, today)
        val doneOne = first.mapIndexed { i, p -> if (i == 0) p.copy(done = true) else p }
        val again = PlanGen.generate(g, listOf("Relieve", "Clima"), today, today, existing = doneOne)
        assertEquals(1, again.count { it.done }); assertEquals(first.size, again.size)
        assertEquals(1, again.count { it.title == first[0].title })
        // Un solo día disponible: práctica y repaso juntos ese día.
        val one = PlanGen.generate(Grade("g2", "Historia", date = "2026-11-21"), listOf("Tema 2"), today, today)
        assertTrue(one.all { it.date == today }); assertTrue(one.any { it.review })
    }

    @Test fun planTopicsCanBeRecoveredForReview() {
        val g = Grade("l", "Lengua", date = "2026-11-27")
        val p = PlanGen.generate(g, listOf("La casa de Bernarda Alba"), "2026-11-20", "2026-11-20")
        assertEquals(listOf("La casa de Bernarda Alba"), PlanGen.topicsOf(p))
        val q = PlanGen.generate(Grade("g", "Geografía", date = "2026-11-27"), listOf("Tema 5", "Tema 6: Clima"), "2026-11-20", "2026-11-20")
        assertEquals(listOf("Tema 5", "Tema 6: Clima"), PlanGen.topicsOf(q))
    }
}
